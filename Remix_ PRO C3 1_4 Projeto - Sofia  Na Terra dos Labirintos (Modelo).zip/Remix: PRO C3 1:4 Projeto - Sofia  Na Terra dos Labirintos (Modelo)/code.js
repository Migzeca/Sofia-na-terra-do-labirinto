var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//criando a jogadora Sofia
var Sofia = createSprite(20,25,18,18);
    Sofia.shapeColor = "pink";

//criando a taça falsa
 var tacafalsa = createSprite(132,365,18,18);
     tacafalsa.shapeColor = "GRAY";

//criando as paredes do labirinto (parede1 - parede2)
  var papelao1 = createSprite(83,46,20,100);
  papelao1.shapeColor = "RED";
  
  var papelao2 = createSprite(53,221,100,20);
   papelao2.shapeColor = "RED";

  var papelao3 = createSprite(172,217,20,100);
   papelao3.shapeColor = "RED";

  var papelao4 = createSprite(232,217,20,100);
   papelao4.shapeColor = "RED";

  var papelao5 = createSprite(96,88,100,20);
   papelao5.shapeColor = "RED";

  var papelao6 = createSprite(100,222,20,100);
   papelao6.shapeColor = "RED";

  var papelao7 = createSprite(200,52,20,100);
   papelao7.shapeColor = "RED";

  var papelao8 = createSprite(277,226,100,20);
    papelao8.shapeColor = "RED";
 
  var papelao9 = createSprite(303,268,20,100);
   papelao9.shapeColor = "RED";

  var papelao10 = createSprite(298,91,100,20);
   papelao10.shapeColor = "RED";

  var papelao11 = createSprite(302,318,100,20);
   papelao11.shapeColor = "RED";

  var papelao12 = createSprite(303,138,20,100);
   papelao12.shapeColor = "RED";

  var papelao13 = createSprite(35,280,20,100);
   papelao13.shapeColor = "RED";

  var papelao14 = createSprite(262,378,20,100);
   papelao14.shapeColor = "RED";

  var papelao15 = createSprite(35,358,20,100);
   papelao15.shapeColor = "RED";

  var papelao15 = createSprite(100,258,20,100);
   papelao15.shapeColor = "RED";

  var papelao16 = createSprite(172,258,20,100);
   papelao16.shapeColor = "RED";

  var papelao17 = createSprite(232,258,20,100);
   papelao17.shapeColor = "RED";

  var papelao18 = createSprite(172,258,20,100);
   papelao18.shapeColor = "RED";

 var papelao19 = createSprite(252,12,100,20);
   papelao19.shapeColor = "RED";

 var papelao20 = createSprite(352,12,100,20);
   papelao20.shapeColor = "RED";

 var papelao21 = createSprite(142,12,100,20);
   papelao21.shapeColor = "RED";

//cria a taça
var taca = createSprite(378,384,20,20);
  taca.shapeColor = "orange";


function draw() {
 //mudando a cor do plano de fundo para branco
  background("white");
  
  createEdgeSprites();
 Sofia.bounceOff(edges);
 Sofia.bounceOff(papelao1);
 Sofia.bounceOff(papelao2);
 Sofia.bounceOff(papelao3);
 Sofia.bounceOff(papelao4);
 Sofia.bounceOff(papelao5);
 Sofia.bounceOff(papelao6);
 Sofia.bounceOff(papelao7);
 Sofia.bounceOff(papelao8);
 Sofia.bounceOff(papelao9);
 Sofia.bounceOff(papelao10);
 Sofia.bounceOff(papelao11);
 Sofia.bounceOff(papelao12);
 Sofia.bounceOff(papelao13);
 Sofia.bounceOff(papelao14);
 Sofia.bounceOff(papelao15);
 Sofia.bounceOff(papelao16);
 Sofia.bounceOff(papelao17);
 Sofia.bounceOff(papelao18);
 Sofia.bounceOff(papelao19);
 Sofia.bounceOff(papelao20);
 Sofia.bounceOff(papelao21);

drawSprites();

if (keyDown(RIGHT_ARROW)){
    Sofia.velocityX = 2;
    Sofia.velocityY = 0;
  }
  if (keyDown(LEFT_ARROW)){
    Sofia.velocityX = -2;
    Sofia.velocityY = 0;
  }
  if (keyDown(UP_ARROW)){
    Sofia.velocityX = 0;
    Sofia.velocityY = -2;
  }
  if (keyDown(DOWN_ARROW)){
    Sofia.velocityX = 0;
    Sofia.velocityY = 2;
  }
  
  if (Sofia.isTouching(taca)){
  stroke(0);
    fill(0);
    textSize(34);
    text("final bom",116,206);
    Sofia.setVelocity(0,0);
    
  }

  if (Sofia.isTouching(tacafalsa)){
  stroke(0);
    fill(0);
    textSize(34);
    text("final ruim",116,206);
    Sofia.setVelocity(0,0);
    
  }
}


























































// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
